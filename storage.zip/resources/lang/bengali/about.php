<?php

return [

	'page_heading' => 'আমাদের সম্পকে',
	'page_subheading' => 'We from LICT',




];