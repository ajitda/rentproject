<?php

return [

	'page_heading' => 'About Us',
	'page_subheading' => 'We from LICT'




];