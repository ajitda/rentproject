@extends('layouts.app')
@section('content')
	<h1>{{__('about.page_heading')}}</h1>
	<h2>{{__('about.page_subheading')}}</h2>
@endsection