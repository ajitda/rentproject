<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AddCatagory extends Model
{
    protected $fillable = ['name', 'slug', 'description'];


    
}
