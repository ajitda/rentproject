<?php $__env->startSection('content'); ?>
	<div class="">
		<div class="container">
			<div class="col-sm-8 col-sm-offset-2">
				<div class="panel panel-default">
					<div class="panel-heading">
						<h1>Creat Add <a href="<?php echo e(url('adds')); ?>" class="btn btn-primary pull-right">Back</a></h1>
					</div>
					<div class="panel-body">
						<!-- <?php if(count($errors->all()) > 0): ?>
						<div class="alert alert-danger">
							<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<li><?php echo e($error); ?></li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
						<?php endif; ?> -->
						<form method="POST" action="<?php echo e(route('adds.store')); ?>" enctype="multipart/form-data">
							<?php echo e(csrf_field()); ?>

							<div class="form-group <?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
								<label for="name">name</label>
								<input type="text" id="name" name="name" class="form-control">
								<?php if($errors->has('name')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
							</div>
							<div class="form-group <?php echo e($errors->has('description') ? ' has-error' : ''); ?>">
								<label for="description">Description</label>
								<textarea id="description" name="description" class="form-control">
								</textarea>
								<?php if($errors->has('description')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('description')); ?></strong>
                                    </span>
                                <?php endif; ?>
							</div>
							<div class="form-group <?php echo e($errors->has('image') ? ' has-error' : ''); ?>">
								<label for="image">Upload your add image</label>
								<input type="file" id="image" name="image" class="form-control">
								<?php if($errors->has('image')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('image')); ?></strong>
                                    </span>
                                <?php endif; ?>
							</div>
							<div class="form-group <?php echo e($errors->has('price') ? ' has-error' : ''); ?>">
								<label for="price">Price</label>
								<input type="number" id="price" name="price" class="form-control">
								<?php if($errors->has('price')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('price')); ?></strong>
                                    </span>
                                <?php endif; ?>
							</div>
							<div class="form-group <?php echo e($errors->has('add_category_id') ? ' has-error' : ''); ?>">
								<label for="add_category_id">phone</label>
								<select name="add_category_id" id="add_category_id" class="form-control">
									<?php $__currentLoopData = $addcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>

								<?php if($errors->has('add_category_id')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('add_category_id')); ?></strong>
                                    </span>
                                <?php endif; ?>
							</div>
							
							<button type="submit" class="btn btn-primary">submit</button>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>