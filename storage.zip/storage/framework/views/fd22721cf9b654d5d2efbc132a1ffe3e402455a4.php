<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>TO-LET | Find the best houses for your livings</title>

    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('css/styles.css')); ?>">

</head>
<body>

    <script src="<?php echo e(asset('js/app.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('js/jquery.magnific-popup.min.js')); ?>" type="text/javascript"></script>
   <script src="<?php echo e(asset('js/jquery.scrolly.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('js/scripts.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/phoneformat.js')); ?>" type="text/javascript"></script>

    
    <header id="header" role="banner">
        <div class="container-fluid">
            <a href="<?php echo e(url('/')); ?>" class="logo">TO-LET</a>
            <div class="user-menu">
                <?php if(Route::has('login')): ?>
                    <?php if(Auth::check()): ?>
                    <li class="dropdown" style="list-style: none;">
                            <a href="#" class="dropdown-toggle link" data-toggle="dropdown" role="button" aria-expanded="false">
                                <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                            </a>

                            <ul class="dropdown-menu" role="menu">
                                <li><a href="<?php echo e(url('/home')); ?>">Dashboard</a></li>
                                <li>
                                    <a href="<?php echo e(route('logout')); ?>"
                                        onclick="event.preventDefault();
                                                 document.getElementById('logout-form').submit();">
                                        Logout
                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo e(csrf_field()); ?>

                                    </form>
                                </li>
                            </ul>
                        </li>
                    <?php else: ?>
                        <a class="link signup-modal" href="<?php echo e(url('/hosts/create')); ?>">Register</a>
                        <a class="signup-link" >Login</a>
                    <?php endif; ?>
                    <!-- <a class="link signup-modal">Register</a>
                    <a class="signup-link">Sign in</a> -->
                <?php endif; ?>
                <div class="user-box">
                    <form id="login-form" method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo e(csrf_field()); ?>

                        <div class="input-box">
                            <input id="txtUsername" type="text" name="email" class="form-input" placeholder="Email">
                            <input id="txtPassword" type="password" name="password" class="form-input password-input" placeholder="Password">
                            <a href="#">Forgot password?</a>
                        </div>
                        <button id="loginBtn" type="submit" class="btn btn-action">
                            Login
                        </button>
                        <a href="/fbauth" class="btn">Connect with <strong>facebook</strong></a>
                    </form>
                </div>
            </div>
        </div>
    </header>

    <script type="text/javascript">
    $(function() {
        setInterval(function() {

            if (window.loginFlag === "true") {
                window.loginFlag = "false";
                $('#headerContent').load('HeaderContent');
            }},  1000);
    });
</script>

<main id="content" class="homepage">
    <div class="page-header" id="headerContent" style="height:250px">
       <div class="parallax-bg" data-velocity=".5"></div>
        <div class="header-content">
            <h1 class="title">Add Details</h1>
        </div>
    </div>
    <div class="container-fluid">
        <div class="page-content">

            <div class="listings-grid">
                <div class="row">
                    <div class="col-sm-5 col-sm-offset-1">
                        <img src="<?php echo e(asset($add->image)); ?>" alt="" class="img-responsive">
                    </div>
                    <div class="col-sm-5">
                        <div class="add-details" style="padding-left:20px;">
                            <h1><?php echo e($add->name); ?></h1>
                            <h2><b><mark>Price: <?php echo e($add->price); ?></mark></b></h2>
                            <p><?php echo e($add->description); ?></p>
                            <h4><b>Address:</b> <?php echo e($add->host->address); ?><br> <?php echo e($add->host->city); ?>-<?php echo e($add->host->zip); ?>, <?php echo e($add->host->state); ?></h4>
                            <h2><b>Contact: <a href="callto:<?php echo e($add->host->phone); ?>"><?php echo e($add->host->phone); ?></a></b></h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

    
<footer id="footer" role="contentinfo">
    <div class="footer-nav contain-row">
        <div class="footer-block">
            <ul>
                <li class="footer-block-title">Company</li>
                <li><a href="#">About</a></li>
                <li><a href="#">Careers</a></li>
                <li><a href="#">Blog</a></li>
                <li><a href="#">Policies</a></li>
            </ul>
        </div>
        <div class="footer-block">
            <ul>
                <li class="footer-block-title">Listing</li>
                <li><a href="#">Why List</a></li>
                <li><a href="#">Safety</a></li>
                <li><a href="#">Terms</a></li>
                <li><a href="#">Policies</a></li>
            </ul>
        </div>
        <div class="footer-block">
            <ul>
                <li class="footer-block-title">Address</li>
                <li>LICT, Chittagong<br>Bangladesh<br>4000</li>
            </ul>
        </div>
        <div class="footer-block">
            <ul>
                <li class="footer-block-title">Contact us</li>
                <li>031-438953</li>
                <li>info@to-let.com</li>
            </ul>
        </div>
    </div>
    <ul class="footer-social">
        <li class="ico-facebook"><a href="#">facebook</a></li>
        <li class="ico-google-plus"><a href="#">google</a></li>
        <li class="ico-twitter"><a href="#">twitter</a></li>
        <li class="ico-instagram"><a href="#">instagram</a></li>
    </ul>
    <p class="copyright">&copy; All rights reserved by <b>GROUP-G</b> lict batch TUP-OFF-H-38</p>
</footer>
</body>
</html>