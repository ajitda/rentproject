<?php $__env->startSection('content'); ?>
	<div class="row">
		<div class="container">
			<div class="panel panel-default">
				<div class="panel-heading">
					<h1>Hosts List <a href="<?php echo e(url('hosts/create')); ?>" class="btn btn-primary pull-right">Create</a></h1>
				</div>
				<div class="panel-body">
					<table class="table table-bordered table-striped">
						<thead>
							<tr>
								<td>Sl</td>
								<td>name</td>
								<td>email</td>
								<td>phone</td>
								<td>address</td>
								<td>city</td>
								<td>zip</td>
								<td>state</td>
								<td>country</td>
							</tr>
						</thead>
						<tbody>
							<?php $__currentLoopData = $hosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $host): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo e($host->id); ?></td>
								<td><?php echo e($host->name); ?></td>
								<td><?php echo e($host->email); ?></td>
								<td><?php echo e($host->phone); ?></td>
								<td><?php echo e($host->address); ?></td>
								<td><?php echo e($host->city); ?></td>
								<td><?php echo e($host->zip); ?></td>
								<td><?php echo e($host->state); ?></td>
								<td><?php echo e($host->country); ?></td>
							</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>