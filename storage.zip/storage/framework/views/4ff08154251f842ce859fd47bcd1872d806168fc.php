<?php $__env->startSection('content'); ?>
	<div class="row">
		<div class="container">
			<div class="col-sm-8 col-sm-offset-2">
				<div class="panel panel-default">
					<div class="panel-heading">
						<h1>User Registration <a href="<?php echo e(url('hosts')); ?>" class="btn btn-primary pull-right">Back</a></h1>
					</div>
					<div class="panel-body">
						<!-- <?php if(count($errors->all()) > 0): ?>
						<div class="alert alert-danger">
							<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<li><?php echo e($error); ?></li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
						<?php endif; ?> -->
						<form method="POST" action="<?php echo e(route('hosts.store')); ?>">
							<?php echo e(csrf_field()); ?>

							<div class="form-group <?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
								<label for="name">name</label>
								<input type="text" id="name" name="name" class="form-control">
								<?php if($errors->has('name')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
							</div>
							<div class="form-group <?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
								<label for="email">email</label>
								<input type="email" id="email" name="email" class="form-control">
								<?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
							</div>
							<div class="form-group <?php echo e($errors->has('phone') ? ' has-error' : ''); ?>">
								<label for="phone">phone</label>
								<input type="number" id="phone" name="phone" class="form-control">
								<?php if($errors->has('phone')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('phone')); ?></strong>
                                    </span>
                                <?php endif; ?>
							</div>
							<div class="form-group <?php echo e($errors->has('address') ? ' has-error' : ''); ?>">
								<label for="address">address</label>
								<input type="text" id="address" name="address" class="form-control">
								<?php if($errors->has('address')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('address')); ?></strong>
                                    </span>
                                <?php endif; ?>
							</div>
							<div class="form-group <?php echo e($errors->has('city') ? ' has-error' : ''); ?>">
								<label for="city">city</label>
								<input type="text" id="city" name="city" class="form-control">
								<?php if($errors->has('city')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('city')); ?></strong>
                                    </span>
                                <?php endif; ?>
							</div>
							<div class="form-group <?php echo e($errors->has('zip') ? ' has-error' : ''); ?>">
								<label for="zip">zip</label>
								<input type="number" id="zip" name="zip" class="form-control">
								<?php if($errors->has('zip')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('zip')); ?></strong>
                                    </span>
                                <?php endif; ?>
							</div>
							<div class="form-group <?php echo e($errors->has('state') ? ' has-error' : ''); ?>">
								<label for="state">state</label>
								<input type="text" id="state" name="state" class="form-control">
								<?php if($errors->has('state')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('state')); ?></strong>
                                    </span>
                                <?php endif; ?>
							</div>
							<div class="form-group <?php echo e($errors->has('country') ? ' has-error' : ''); ?>">
								<label for="country">country</label>
								<input type="text" id="country" name="country" class="form-control">
								<?php if($errors->has('country')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('country')); ?></strong>
                                    </span>
                                <?php endif; ?>
							</div>
							<div class="form-group <?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
								<label for="password">Password</label>
								<input type="password" id="password" name="password" class="form-control">
								<?php if($errors->has('password')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
							</div>
							<button type="submit" class="btn btn-primary">submit</button>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>