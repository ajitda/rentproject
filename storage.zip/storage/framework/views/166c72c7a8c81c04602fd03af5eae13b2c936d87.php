<?php $__env->startSection('content'); ?>
	<div class="container">
		<div class="row">
			<div class="panel panel-default">
				<div class="panel-heading">
					<h1>Adds List <a href="<?php echo e(url('adds/create')); ?>" class="btn btn-primary pull-right">Create</a></h1>
				</div>
				<div class="panel-body">
					<table class="table table-bordered table-striped">
						<thead>
							<tr>
								<td>Sl</td>
								<td>name</td>
								<td>description</td>
								<td>image</td>
								<td>category</td>
								<td>Created By</td>
								<td>Created at</td>
								<td>Status</td>
								<?php if(Auth::user()->hasRole("admin")): ?>
								<td>Action</td>
								<?php endif; ?>
							</tr>
						</thead>
						<tbody>
							<?php $__currentLoopData = $adds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $add): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo e($add->id); ?></td>
								<td><?php echo e($add->name); ?></td>
								<td><?php echo e($add->description); ?></td>
								<td><img src="<?php echo e($add->image); ?>" width="100" alt="<?php echo e($add->name); ?>"></td>
								<td><?php echo e($add->add_category->name); ?></td>
								<td><?php echo e($add->host->name); ?></td>
								<td><?php echo e($add->created_at); ?></td>
								<?php if($add->type == false): ?>
								<td>Pending</td>
								<?php else: ?>
								<td>Published</td>

								<?php endif; ?>
								<?php if(Auth::user()->hasRole("admin")): ?>
								<td><?php if($add->type == false): ?>
									<a href="<?php echo e(route('add.publish', $add->id)); ?>" class="btn btn-primary">Publish</a>
									<?php else: ?>
									<a href="<?php echo e(route('add.unpublish', $add->id)); ?>" class="btn btn-primary">Unpublish</a>
									<?php endif; ?>
								</td>
								<?php endif; ?>
							</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>