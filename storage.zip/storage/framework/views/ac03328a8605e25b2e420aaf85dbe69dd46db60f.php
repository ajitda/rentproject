<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Dashboard</div>

                <div class="panel-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if(Auth::user()->hasRole('admin')): ?>
                   <div class="row">
                        <div class="col-sm-1"></div>
                        <div class="col-sm-4 well"><a href="<?php echo e(route('adds.index')); ?>">Published Adds : <?php echo e(DB::table('adds')->where('type', 1)->count()); ?></a></div>
                        <div class="col-sm-2"></div>
                        <div class="col-sm-4 well"><a href="<?php echo e(route('adds.index')); ?>">Pending Adds : <?php echo e(DB::table('adds')->where('type', 0)->count()); ?></a></div>
                        <div class="col-sm-1"></div>
                    </div>
                    <div class="row">
                        <div class="col-sm-1"></div>
                        <div class="col-sm-4 well"><a href="<?php echo e(route('hosts.index')); ?>">Total Hosts : <?php echo e(DB::table('hosts')->count()); ?></a></div>
                        <div class="col-sm-2"></div>
                        <div class="col-sm-4 well"><a href="<?php echo e(route('addcategory.index')); ?>">Total Categories : <?php echo e(DB::table('add_catagories')->count()); ?></a></div>
                    </div>
                    <?php endif; ?>
                    <?php if(Auth::user()->hasRole('host')): ?>
                     <div class="row">
                        <div class="col-sm-1"></div>
                        <div class="col-sm-4 well"><a href="<?php echo e(route('adds.index')); ?>">Your Adds</a></div>
                        <div class="col-sm-1"></div>
                        <div class="col-sm-4 well"><a href="<?php echo e(route('adds.create')); ?>">Create Your Adds</a></div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>